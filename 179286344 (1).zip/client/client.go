package client

// CS 161 Project 2

// You MUST NOT change these default imports. ANY additional imports
// may break the autograder!

import (
	"encoding/json"

	userlib "github.com/cs161-staff/project2-userlib"
	"github.com/google/uuid"

	// hex.EncodeToString(...) is useful for converting []byte to string

	// Useful for string manipulation
	"strings"

	// Useful for formatting strings (e.g. `fmt.Sprintf`).
	"fmt"

	// Useful for creating new error messages to return using errors.New("...")
	"errors"

	// Optional.
	_ "strconv"
)

// This serves two purposes: it shows you a few useful primitives,
// and suppresses warnings for imports not being used. It can be
// safely deleted!
func someUsefulThings() {

	// Creates a random UUID.
	randomUUID := uuid.New()

	// Prints the UUID as a string. %v prints the value in a default format.
	// See https://pkg.go.dev/fmt#hdr-Printing for all Golang format string flags.
	userlib.DebugMsg("Random UUID: %v", randomUUID.String())

	// Creates a UUID deterministically, from a sequence of bytes.
	hash := userlib.Hash([]byte("user-structs/alice"))
	deterministicUUID, err := uuid.FromBytes(hash[:16])
	if err != nil {
		// Normally, we would `return err` here. But, since this function doesn't return anything,
		// we can just panic to terminate execution. ALWAYS, ALWAYS, ALWAYS check for errors! Your
		// code should have hundreds of "if err != nil { return err }" statements by the end of this
		// project. You probably want to avoid using panic statements in your own code.
		panic(errors.New("An error occurred while generating a UUID: " + err.Error()))
	}
	userlib.DebugMsg("Deterministic UUID: %v", deterministicUUID.String())

	// Declares a Course struct type, creates an instance of it, and marshals it into JSON.
	type Course struct {
		name      string
		professor []byte
	}

	course := Course{"CS 161", []byte("Nicholas Weaver")}
	courseBytes, err := json.Marshal(course)
	if err != nil {
		panic(err)
	}

	userlib.DebugMsg("Struct: %v", course)
	userlib.DebugMsg("JSON Data: %v", courseBytes)

	// Generate a random private/public keypair.
	// The "_" indicates that we don't check for the error case here.
	var pk userlib.PKEEncKey
	var sk userlib.PKEDecKey
	pk, sk, _ = userlib.PKEKeyGen()
	userlib.DebugMsg("PKE Key Pair: (%v, %v)", pk, sk)

	// Here's an example of how to use HBKDF to generate a new key from an input key.
	// Tip: generate a new key everywhere you possibly can! It's easier to generate new keys on the fly
	// instead of trying to think about all of the ways a key reuse attack could be performed. It's also easier to
	// store one key and derive multiple keys from that one key, rather than
	originalKey := userlib.RandomBytes(16)
	derivedKey, err := userlib.HashKDF(originalKey, []byte("mac-key"))
	if err != nil {
		panic(err)
	}
	userlib.DebugMsg("Original Key: %v", originalKey)
	userlib.DebugMsg("Derived Key: %v", derivedKey)

	// A couple of tips on converting between string and []byte:
	// To convert from string to []byte, use []byte("some-string-here")
	// To convert from []byte to string for debugging, use fmt.Sprintf("hello world: %s", some_byte_arr).
	// To convert from []byte to string for use in a hashmap, use hex.EncodeToString(some_byte_arr).
	// When frequently converting between []by te and string, just marshal and unmarshal the data.
	//
	// Read more: https://go.dev/blog/strings

	// Here's an example of string interpolation!
	_ = fmt.Sprintf("%s_%d", "file", 1)
}

// This is the type definition for the User struct.
// A Go struct is like a Python or Java class - it can have attributes
// (e.g. like the Username attribute) and methods (e.g. like the StoreFile method below).
type User struct {
	Username           string
	Password           string
	PublicKey          userlib.PKEEncKey
	PrivateKey         userlib.PKEDecKey
	SignKey            userlib.DSSignKey
	VerifyKey          userlib.DSVerifyKey
	MapofFileSharing   map[string][]string
	SourcekeyEncryptor []byte
	// You can add other attributes here if you want! But note that in order for attributes to
	// be included when this struct is serialized to/from JSON, they must be capitalized.
	// On the flipside, if you have an attribute that you want to be able to access from
	// this struct's methods, but you DON'T want that value to be included in the serialized value
	// of this struct that's stored in datastore, then you can use a "private" variable (e.g. one that
	// begins with a lowercase letter).
}

type InviteInfo struct {
	ContentUUID          userlib.UUID
	Creatorsheadfilename string
	Fileownerusername    string
	SourceKeyForthefile  []byte
}

type InvitewithSig struct {
	Alltheinfo       []byte //encrypted with symkey
	SymKeyCiphertext []byte //encrypted with public key, decrypted with private
	Sig              []byte
}

// NOTE: The following methods have toy (insecure!) implementations.

func InitUser(username string, password string) (userdataptr *User, err error) {
	var userdata User
	//check if user already exists or if username is empty
	useruuid, err := uuid.FromBytes(userlib.Hash([]byte(username))[0:16])
	if err != nil {
		return nil, err
	}

	_, ok := userlib.DatastoreGet(useruuid)

	if ok {
		err = errors.New("username already used")
		return nil, err
	}

	if username == "" {
		err = errors.New("no empty usernames")
		return nil, err
	}

	//set all the attributes
	userdata.Username = username
	userdata.Password = password
	userdata.PublicKey, userdata.PrivateKey, err = userlib.PKEKeyGen()
	if err != nil {
		return nil, err
	}
	userdata.SignKey, userdata.VerifyKey, err = userlib.DSKeyGen()
	if err != nil {
		return nil, err
	}
	userdata.MapofFileSharing = make(map[string][]string)
	userdata.SourcekeyEncryptor = userlib.RandomBytes(16)
	//save public and verify key in keystore
	err = userlib.KeystoreSet(username+"/publickey", userdata.PublicKey)
	if err != nil {
		return nil, err
	}
	err = userlib.KeystoreSet(username+"/verifykey", userdata.VerifyKey)
	if err != nil {
		return nil, err
	}

	//JSON marshall the User struct
	userjson, err := json.Marshal(userdata)
	if err != nil {
		return nil, errors.New("ijeb")
	}

	//store the user struct using a randomly generated key
	randomKey := userlib.RandomBytes(16)
	userciphertext := userlib.SymEnc(randomKey, userlib.RandomBytes(16), userjson)
	userlib.DatastoreSet(useruuid, userciphertext)
	if err != nil {
		return nil, err
	}

	//store that random key using a deterministic key
	//use userciphertext to make the deterministic key
	sourcekey := userlib.Argon2Key([]byte(password), []byte(username), 16)
	determinkey, err := userlib.HashKDF(sourcekey, userciphertext)
	if err != nil {
		return nil, err
	}
	keyciphertext := userlib.SymEnc(determinkey[0:16], userlib.RandomBytes(16), randomKey)
	//store it at UUID: [hashed version of useruuid]
	keyuuid, err := uuid.FromBytes(userlib.Hash(useruuid[:])[0:16])
	if err != nil {
		return nil, err
	}
	userlib.DatastoreSet(keyuuid, keyciphertext)

	//HMAC
	//HMAC the user ciphertext using the rgk
	HMACofuserciphertext, err := userlib.HMACEval(randomKey, userciphertext)
	if err != nil {
		return nil, err
	}

	//Store the MAC of the userciphtext at a UUID which is from the bytes of  Hash( Hash(userciphertext) || Hash("MAC") ) [:16]
	hashedMAC := userlib.Hash([]byte("MAC"))
	hasheduserandMAC := append(userlib.Hash(userciphertext), hashedMAC...)
	hashuuid, err := uuid.FromBytes(userlib.Hash(hasheduserandMAC)[:16])
	if err != nil {
		return nil, err
	}
	userlib.DatastoreSet(hashuuid, HMACofuserciphertext)
	///

	return &userdata, nil
}

func GetUser(username string, password string) (userdataptr *User, err error) {
	// Regenerate user UUID
	useruuid, err := uuid.FromBytes(userlib.Hash([]byte(username))[0:16])
	if err != nil {
		return nil, err
	}
	//Make sure this user exists (meaning its UUID is being used)--> return error if it does not exist
	userciphertext, ok := userlib.DatastoreGet(useruuid)
	if !(ok) {
		err = errors.New("no user with that username")
		return nil, err
	}
	//Hash & slice that to generate the randomly generated key (RGK) UUID
	keyuuid, err := uuid.FromBytes(userlib.Hash(useruuid[:])[0:16])
	if err != nil {
		return nil, err
	}
	//Fetch the encrypted RGK from Datastore
	RGkeyciphertext, ok := userlib.DatastoreGet(keyuuid)
	if !(ok) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff fjfkc")
		return nil, err
	}
	if len(RGkeyciphertext) != 32 {
		return nil, errors.New("ERRORMSG: key CT tampered with")
	}
	//Regenerate the deterministic key
	sourcekey := userlib.Argon2Key([]byte(password), []byte(username), 16)
	determinkey, err := userlib.HashKDF(sourcekey, userciphertext)
	if err != nil {
		return nil, err
	}
	//Decrypt RGK
	randgenkey := userlib.SymDec(determinkey[:16], RGkeyciphertext)
	//Fetch user ciphertext from user UUID in Datastore (Done already above)
	//Generate an HMAC of the retrieved user ciphertext
	HMACofretrieveduserciphertext, err := userlib.HMACEval(randgenkey, userciphertext)
	if err != nil {
		return nil, err
	}
	//Compare current MAC to MAC when we stored the user→ return error if MAC’s are not equal
	//Regenerate the UUID of where we stored the HMAC
	hashedMAC := userlib.Hash([]byte("MAC"))
	hasheduserandMAC := append(userlib.Hash(userciphertext), hashedMAC...)
	hashuuid, err := uuid.FromBytes(userlib.Hash(hasheduserandMAC)[:16])
	if err != nil {
		return nil, err
	}
	//Datastoreget the HMAC from that UUID
	HMACoforiginaluserciphertext, ok := userlib.DatastoreGet(hashuuid)
	if !(ok) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff fvf")
		return nil, err
	}
	//Compare
	equal := userlib.HMACEqual(HMACoforiginaluserciphertext, HMACofretrieveduserciphertext)
	if !(equal) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff kj")
		return nil, err
	}

	//Decrypt user using RGK
	userjson := userlib.SymDec(randgenkey[:16], userciphertext)
	//Unmarshall user
	var userdata User
	userdataptr = &userdata
	err = json.Unmarshal(userjson, userdataptr)
	if err != nil {
		return nil, errors.New("jhecb")
	}
	//Access the user’s password—> compare it to the attempted password→ return error if password is incorrect
	actualpassword := userdata.Password
	if actualpassword != password {
		err = errors.New("password wrong")
		return nil, err
	}

	return userdataptr, nil
}

func (userdata *User) StoreFile(filename string, content []byte) (err error) {
	if userdata.thisFileWasSharedWithUs(filename) {
		return userdata.StoreSharedFile(filename, content)
	}
	userdata.clearthisfile(filename)
	//Make a UUID (from now on called UUID1) based on the user and file name
	hashedusername := userlib.Hash([]byte(userdata.Username))
	hashedfilename := userlib.Hash([]byte(filename))
	hashedcombine := append(hashedusername, hashedfilename...)
	contentuuid, err := uuid.FromBytes(userlib.Hash(hashedcombine)[:16])

	if err != nil {
		return err
	}
	// Marshall the data
	contentjson, err := json.Marshal(content)
	if err != nil {
		return errors.New("kjd")
	}
	//Store the contents at contentuuid using a randomly generated key
	randomKey := userlib.RandomBytes(16)
	contentciphertext := userlib.SymEnc(randomKey, userlib.RandomBytes(16), contentjson)
	userlib.DatastoreSet(contentuuid, contentciphertext)
	if err != nil {
		return err
	}
	//HMAC the encrypted data using the same randomly generated key
	MACofcontentciphertext, err := userlib.HMACEval(randomKey, contentciphertext)
	if err != nil {
		return err
	}

	// Store the MAC of the contentciphertext at a UUID which is from the bytes of Hash( Hash(hashedcombine) || Hash("MAC") )
	// Hash(Hash(username) || Hash(filename)) --> hashcombine
	// Hash(Hash( Hash(username) || Hash(filename) ) || Hash("MAC") || Hash(contentciphertext)) --> UUID where we save the MAC of contentciphertext
	hashedMAC := userlib.Hash([]byte("MAC"))
	hashedciphertext := userlib.Hash(contentciphertext)
	hashedcombineMAC := append(hashedcombine, hashedMAC...)
	hashedcombineMAC = append(hashedcombineMAC, hashedciphertext...)
	hashuuid, err := uuid.FromBytes(userlib.Hash(hashedcombineMAC)[:16])
	if err != nil {
		return err
	}
	userlib.DatastoreSet(hashuuid, MACofcontentciphertext)

	//Make a new UUID (keyuuid) based on a hash of the contentuuid
	keyuuid, err := uuid.FromBytes(userlib.Hash(contentuuid[:])[0:16])
	if err != nil {
		return err
	}
	//Make a new deterministic key with contentciphertext as the purpose and the user’s source key as the source key
	err = userdata.StoreFileSourceKey(contentuuid)
	if err != nil {
		return err
	}
	sourcekey, err := userdata.GetFileSourceKey(contentuuid)
	if err != nil {
		return err
	}
	determinkey, err := userlib.HashKDF(sourcekey, contentciphertext)
	if err != nil {
		return err
	}
	if sourcekey == nil {
		return errors.New("source keys not being saved for some reason")
	}
	//Encrypt the randomly generated key using the deterministic key
	keyciphertext := userlib.SymEnc(determinkey[0:16], userlib.RandomBytes(16), randomKey)
	//Store the keyciphertext at keyuuid
	userlib.DatastoreSet(keyuuid, keyciphertext)

	// Step 1: Generate the UUID for where we're gonna save the next avaible UUID
	UUIDwherewesavetheUUID, err := GeneratetheUUIDofwherewesavetheUUID(contentuuid, sourcekey)
	if err != nil {
		return err
	}
	// Step 2: Generate the UUID where we'd append to next
	nextuuid, err := GeneratetheUUIDofwhereweappendtonext(contentuuid, sourcekey)
	if err != nil {
		return err
	}
	// Step 3: encrypt the nextUUID through a deterministic key based on the user's source key and headfile's UUID
	nextUUIDkey, err := userlib.HashKDF(sourcekey, contentuuid[:])
	if err != nil {
		return err
	}
	nextUUIDciphertext := userlib.SymEnc(nextUUIDkey[0:16], userlib.RandomBytes(16), nextuuid[:])
	// Step 4: save nextuuidciphertext to UUIDwherewesavetheUUID
	userlib.DatastoreSet(UUIDwherewesavetheUUID, nextUUIDciphertext)

	return nil
}

func (userdata *User) AppendToFile(filename string, content []byte) error {
	//Generate the UUID at that file
	hashedusername := userlib.Hash([]byte(userdata.Username))
	hashedfilename := userlib.Hash([]byte(filename))
	hashedcombine := append(hashedusername, hashedfilename...)
	originalfileuuid, err := uuid.FromBytes(userlib.Hash(hashedcombine)[:16])
	if err != nil {
		return err
	}
	hashedinvitedstring := userlib.Hash([]byte("invited"))
	hashedcombine = append(hashedcombine, hashedinvitedstring...)
	inviteuuid, err := uuid.FromBytes(userlib.Hash(hashedcombine)[:16])
	if err != nil {
		return err
	}
	_, ok := userlib.DatastoreGet(inviteuuid)
	if ok {
		return userdata.AppendtoSharedFile(inviteuuid, content)
	}
	_, ok = userlib.DatastoreGet(originalfileuuid)
	if !(ok) {
		return errors.New("no file with this name associated with this user")
	}
	return userdata.UUIDAppendToFile(originalfileuuid, content, filename)
}

func (userdata *User) LoadFile(filename string) (content []byte, err error) {
	//Regenerate the file’s UUID
	hashedusername := userlib.Hash([]byte(userdata.Username))
	hashedfilename := userlib.Hash([]byte(filename))
	hashedcombine := append(hashedusername, hashedfilename...)
	contentuuid, err := uuid.FromBytes(userlib.Hash(hashedcombine)[:16])
	if err != nil {
		return nil, err
	}
	// check if this is a shared file --> if so, use helper functions which load files just for this
	hashedinvitedstring := userlib.Hash([]byte("invited"))
	hashedcombineinvite := append(hashedcombine, hashedinvitedstring...)
	inviteuuid, err := uuid.FromBytes(userlib.Hash(hashedcombineinvite)[:16])
	if err != nil {
		return nil, err
	}
	_, ok := userlib.DatastoreGet(inviteuuid)
	if ok {
		return userdata.LoadSharedFile(inviteuuid)
	}

	//Make sure this file exists (meaning its UUID is being used)--> return error if it does not exist
	//Fetch encrypted file from contentUUID in Datastore
	contentciphertext, ok := userlib.DatastoreGet(contentuuid)
	if !ok {
		return nil, errors.New(strings.ToTitle("file not found"))
	}
	//Hash & slice contentuuid to generate the randomly generated key (RGK) UUID
	keyuuid, err := uuid.FromBytes(userlib.Hash(contentuuid[:])[0:16])
	if err != nil {
		return nil, err
	}
	//Fetch the encrypted RGK from Datastore
	RGkeyciphertext, ok := userlib.DatastoreGet(keyuuid)
	if len(RGkeyciphertext) != 32 {
		return nil, errors.New("ERRORMSG: key CT tampered with")
	}
	if !(ok) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff dbcj")
		return nil, err
	}
	//Regenerate the deterministic key
	sourcekey, err := userdata.GetFileSourceKey(contentuuid)
	if err != nil {
		return nil, err
	}
	determinkey, err := userlib.HashKDF(sourcekey, contentciphertext)
	if err != nil {
		return nil, err
	}
	//Decrypt RGK
	randgenkey := userlib.SymDec(determinkey[:16], RGkeyciphertext)
	if len(randgenkey) != 16 {
		return nil, errors.New("ERRORMSG: key tampered with")
	}
	//Compare MAC of the original ciphertext and the MAC of the retrieved ciphertext to make sure they match→ if they don’t return error
	//MAC the retrieved ciphertext using the RGK
	//MACofretrievedciphertext, err := userlib.HMACEval(randgenkey, contentciphertext)
	MACofretrievedciphertext, err := userdata.GenerateNewHMAC(filename)
	if err != nil {
		return nil, err
	}
	//Fetch the MAC of the original ciphertext from uuid from the bytes of Hash( Hash(hashedcombine) || Hash("MAC") ) [:16]
	hashedMAC := userlib.Hash([]byte("MAC"))
	hashedciphertext := userlib.Hash(contentciphertext)
	hashedcombineMAC := append(hashedcombine, hashedMAC...)
	hashedcombineMAC = append(hashedcombineMAC, hashedciphertext...)
	hashuuid, err := uuid.FromBytes(userlib.Hash(hashedcombineMAC)[:16])
	if err != nil {
		return nil, err
	}
	MACoforiginalciphertext, ok := userlib.DatastoreGet(hashuuid)
	if !(ok) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff djcd")
		return nil, err
	}
	//Compare the two hashes→ if not equal, return error
	equal := userlib.HMACEqual(MACofretrievedciphertext, MACoforiginalciphertext)
	if !(equal) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff cdck")
		return nil, err
	}

	//Decrypt file using RGK
	contentjson := userlib.SymDec(randgenkey[:16], contentciphertext)
	//Unmarshall the data to get the content
	err = json.Unmarshal(contentjson, &content)
	if err != nil {
		return nil, errors.New("sdfghjk")
	}

	//Check if there is any content at the following UUID
	//generate the next UUID as a Hash( Hash(UUID1) || Hash(“append”) ) [:16]
	nextuuid, err := GeneratetheUUIDofwhereweappendtonext(contentuuid, sourcekey)
	if err != nil {
		return nil, err
	}

	// if there is content at this nextuuid, call our helper function UIDLoadFile on this next uuid and append whatever that func returns to content
	if fileexistshere(nextuuid) {
		nextfilecontent, err := userdata.UUIDLoadFile(contentuuid, nextuuid)
		if err != nil {
			return nil, err
		}
		content = append(content, nextfilecontent...)
	}

	return content, err
}

func (userdata *User) CreateInvitation(filename string, recipientUsername string) (invitationPtr uuid.UUID, err error) {
	// STEP 1: add all the info to an inviteinfo struct (ContentUUID, Headfilename, Sourcekey, Fileownerusername)
	if userdata.thisFileWasSharedWithUs(filename) {
		return userdata.CreateInvitationforaSharedFile(filename, recipientUsername)
	}
	var invitedata InviteInfo
	//headfilename
	invitedata.Creatorsheadfilename = filename
	//contentuuid
	hashedusername := userlib.Hash([]byte(userdata.Username))
	hashedfilename := userlib.Hash([]byte(filename))
	hashedcombine := append(hashedusername, hashedfilename...)
	contentuuid, err := uuid.FromBytes(userlib.Hash(hashedcombine)[:16])
	if err != nil {
		return uuid.Nil, err
	}
	invitedata.ContentUUID = contentuuid
	//sourcekey
	sourcekey, err := userdata.GetFileSourceKey(contentuuid)
	if err != nil {
		return uuid.Nil, err
	}
	if sourcekey == nil {
		return uuid.Nil, errors.New("this file needs to have a saved source key")
	}
	invitedata.SourceKeyForthefile = sourcekey
	// fileownerusername
	invitedata.Fileownerusername = userdata.Username
	// STEP 2: marshall then encrypt the invite info using some symmetric key
	jsoninvitedata, err := json.Marshal(invitedata)
	if err != nil {
		return uuid.Nil, errors.New("momom")
	}
	recipientPK, ok := userlib.KeystoreGet(recipientUsername + "/publickey")
	if !(ok) {
		return uuid.Nil, errors.New("no user receipient found")
	}
	randomkey := userlib.RandomBytes(16)
	invitedataciphertext := userlib.SymEnc(randomkey, userlib.RandomBytes(16), jsoninvitedata)
	randomkeyciphertext, err := userlib.PKEEnc(recipientPK, randomkey)
	if err != nil {
		return uuid.Nil, err
	}
	// STEP 3: make a invite with sig struct
	var invitewithsig InvitewithSig
	invitewithsig.Alltheinfo = invitedataciphertext
	invitewithsig.Sig, err = userlib.DSSign(userdata.SignKey, invitedataciphertext)
	if err != nil {
		return uuid.Nil, err
	}
	invitewithsig.SymKeyCiphertext = randomkeyciphertext
	// STEP 4: marshal that, store it to some random UUID, and return the rando UUID
	jsoninvitewithsig, err := json.Marshal(invitewithsig)
	if err != nil {
		return uuid.Nil, errors.New("lapalpapa")
	}
	invitationPtr = uuid.New()
	userlib.DatastoreSet(invitationPtr, jsoninvitewithsig)

	// STEP 0: add this to the our map
	listofusers, ok := userdata.MapofFileSharing[filename]
	if ok {
		recipientalreadyinlist := false
		for i := 0; i < len(userdata.MapofFileSharing[filename]); i++ {
			if userdata.MapofFileSharing[filename][i] == recipientUsername {
				recipientalreadyinlist = true
			}
		}
		if !recipientalreadyinlist {
			userdata.MapofFileSharing[filename] = append(listofusers, recipientUsername)
		}
	} else {
		userdata.MapofFileSharing[filename] = []string{recipientUsername}
	}
	return invitationPtr, err
}

func (userdata *User) AcceptInvitation(senderUsername string, invitationPtr uuid.UUID, filename string) error {
	//return error if The caller already has a file with the given filename in their personal file namespace.
	hashedusername := userlib.Hash([]byte(userdata.Username))
	hashedfilename := userlib.Hash([]byte(filename))
	hashedcombine := append(hashedusername, hashedfilename...)
	contentuuid, err := uuid.FromBytes(userlib.Hash(hashedcombine)[:16])
	if err != nil {
		return err
	}
	_, ok := userlib.DatastoreGet(contentuuid)
	if ok {
		return errors.New("file already exists here")
	}
	// also checking if this file is saved at a different uuid
	hashedinvitedstring := userlib.Hash([]byte("invited"))
	hashedcombineinvite := append(hashedcombine, hashedinvitedstring...)
	inviteuuid, err := uuid.FromBytes(userlib.Hash(hashedcombineinvite)[:16])
	if err != nil {
		return err
	}
	_, ok = userlib.DatastoreGet(inviteuuid)
	if ok {
		return errors.New("file already exists here")
	}
	// STEP 1: get the jsoninvitewithsig from invitationPtr
	jsoninvitewithsig, ok := userlib.DatastoreGet(invitationPtr)
	if !ok {
		return errors.New("no content at that pointer")
	}
	// unmarshall jsoninvitewithsig and set it to a var invitewithsig InvitewithSig
	var invitewithsig InvitewithSig
	invitewithsigptr := &invitewithsig
	err = json.Unmarshal(jsoninvitewithsig, invitewithsigptr)
	if err != nil {
		return errors.New("joppjpoo")
	}
	// verify the signature using the sender's public verify key, AlltheInfo ciphertext as msg, and the sig as the sig
	sendervk, ok := userlib.KeystoreGet(senderUsername + "/verifykey")
	if !ok {
		return errors.New("sender probably isn't real")
	}
	err = userlib.DSVerify(sendervk, invitewithsig.Alltheinfo, invitewithsig.Sig)
	if err != nil {
		return err
	}
	// if verified decrypt the symkey using our own private key, the all the info with our sym key
	symkey, err := userlib.PKEDec(userdata.PrivateKey, invitewithsig.SymKeyCiphertext)
	if err != nil {
		return err
	}
	jsoninvitedata := userlib.SymDec(symkey, invitewithsig.Alltheinfo)
	if err != nil {
		return err
	}
	// Store the invitedataciphertext at a UUID related to the inputted filename (call it inviteuuid)
	err = userdata.StoreInviteFile(filename, inviteuuid, jsoninvitedata)
	if err != nil {
		return err
	}
	// NOTE: then, we when we loadfile, we're going to check if inviteuuid is being used. If so, we're going to call a helper function and use a whole different set of rules
	// make sure the invite is still valid
	_, err = userdata.LoadFile(filename)
	if err != nil {
		return err
	}
	return nil
}

func (userdata *User) RevokeAccess(filename string, recipientUsername string) error {
	hashedusername := userlib.Hash([]byte(userdata.Username))
	hashedfilename := userlib.Hash([]byte(filename))
	hashedcombine := append(hashedusername, hashedfilename...)
	contentuuid, err := uuid.FromBytes(userlib.Hash(hashedcombine)[:16])
	if err != nil {
		return err
	}
	_, ok := userlib.DatastoreGet(contentuuid)
	if !ok {
		return errors.New("are you revoking a file you never even made?")
	}
	// Step 1: Find the position of recipient username in userdata.MapofFileSharing[filename] and delete it
	sharedusers := userdata.MapofFileSharing[filename]
	fileisnotsharedwiththisuser := true
	for i := 0; i < len(sharedusers); i++ {
		if sharedusers[i] == recipientUsername {
			fileisnotsharedwiththisuser = false
			sharedusers[i] = sharedusers[len(sharedusers)-1]
			break
		}
	}
	if fileisnotsharedwiththisuser {
		return errors.New("file not shared with this user")
	}
	sharedusers = sharedusers[:len(sharedusers)-1]
	// Step 2: download the file
	fileplaintext, err := userdata.LoadFile(filename)
	if err != nil {
		return err
	}
	err = userdata.clearthisfile(filename)
	if err != nil {
		return err
	}
	// Step 3: change the source key
	userdata.StoreFileSourceKey(contentuuid)
	// Step 4: reupload the file
	err = userdata.StoreFile(filename, fileplaintext)
	if err != nil {
		return err
	}
	// Step 4: iterate through the list, calling create invitation for everyone on the list
	for i := 0; i < len(sharedusers); i++ {
		userdata.CreateInvitation(filename, sharedusers[i])
	}
	return nil
}

//// HELPER FUNCTIONS DOWN HERE

func (userdata *User) clearthisfile(filename string) error {
	// generate file uuid
	hashedusername := userlib.Hash([]byte(userdata.Username))
	hashedfilename := userlib.Hash([]byte(filename))
	hashedcombine := append(hashedusername, hashedfilename...)
	firstfileuuid, err := uuid.FromBytes(userlib.Hash(hashedcombine)[:16])
	if err != nil {
		return err
	}
	// delete where it stores its mac
	hashedMAC := userlib.Hash([]byte("MAC"))
	contentciphertext, ok := userlib.DatastoreGet(firstfileuuid)
	if !(ok) {
		return errors.New("clearing trouble")
	}
	hashedciphertext := userlib.Hash(contentciphertext)
	hashedcombineMAC := append(hashedcombine, hashedMAC...)
	hashedcombineMAC = append(hashedcombineMAC, hashedciphertext...)
	hashuuid, err := uuid.FromBytes(userlib.Hash(hashedcombineMAC)[:16])
	userlib.DatastoreDelete(hashuuid)
	if err != nil {
		return err
	}
	// delete its UUIDwherewesavetheUUID
	sourcekey, err := userdata.GetFileSourceKey(firstfileuuid)
	if err != nil {
		return err
	}
	UUIDwherewesavetheUUID, err := GeneratetheUUIDofwherewesavetheUUID(firstfileuuid, sourcekey)
	if err != nil {
		return err
	}
	userlib.DatastoreDelete(UUIDwherewesavetheUUID)
	// delete it and all its appendages
	thisfileUUID := firstfileuuid
	if err != nil {
		return err
	}
	for {
		//delete the contentuuids
		_, ok := userlib.DatastoreGet(thisfileUUID)
		if !(ok) {
			break
		}
		userlib.DatastoreDelete(thisfileUUID)
		//delete the keyuuids
		keyuuid, err := uuid.FromBytes(userlib.Hash(thisfileUUID[:])[0:16])
		if err != nil {
			return err
		}
		_, ok = userlib.DatastoreGet(keyuuid)
		if !(ok) {
			break
		}
		userlib.DatastoreDelete(keyuuid)
		//generate the next UUID as a Hash( Hash(UUID1) || Hash(“append”) ) [:16]
		nextuuid, err := GeneratetheUUIDofwhereweappendtonext(thisfileUUID, sourcekey)
		if err != nil {
			return err
		}
		thisfileUUID = nextuuid
	}
	return nil
}

func (userdata *User) UUIDAppendToFile(originalfileuuid uuid.UUID, content []byte, filename string) error {
	// Regenerate the UUID where we save the UUID that we're going to append to
	sourcekey, err := userdata.GetFileSourceKey(originalfileuuid)
	if err != nil {
		return err
	}
	UUIDwherewesavetheUUID, err := GeneratetheUUIDofwherewesavetheUUID(originalfileuuid, sourcekey)
	if err != nil {
		return err
	}
	// get the encrypted UUID from UUIDwherewesavetheUUID
	encryptednextUUID, ok := userlib.DatastoreGet(UUIDwherewesavetheUUID)
	if !(ok) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff dcdc")
		return err
	}
	// Regenerate the key we encrypted encryptednextUUID with
	if err != nil {
		return err
	}
	nextUUIDkey, err := userlib.HashKDF(sourcekey, originalfileuuid[:])
	if err != nil {
		return err
	}
	// decrypt nextUUID
	nextUUID, err := uuid.FromBytes(userlib.SymDec(nextUUIDkey[:16], encryptednextUUID))
	if err != nil {
		return err
	}
	// Call some storefile on content to nextUUID
	userdata.UUIDStoreFile(nextUUID, content, filename)

	// Update the contents stored at UUIDwherewesavetheUUID
	nextnextUUID, err := GeneratetheUUIDofwhereweappendtonext(nextUUID, sourcekey)
	if err != nil {
		return err
	}
	// Step 2: encrypt the nextUUID through a deterministic key based on the user's source key and headfile's UUID
	nextnextUUIDciphertext := userlib.SymEnc(nextUUIDkey[0:16], userlib.RandomBytes(16), nextnextUUID[:])
	userlib.DatastoreSet(UUIDwherewesavetheUUID, nextnextUUIDciphertext[:])

	return nil
}

func fileexistshere(fileuuid uuid.UUID) (answer bool) {
	_, ok := userlib.DatastoreGet(fileuuid)
	return ok
}

func (userdata *User) UUIDStoreFile(contentuuid uuid.UUID, content []byte, headfilename string) (err error) {
	if err != nil {
		return err
	}
	// Marshall the data
	contentjson, err := json.Marshal(content)
	if err != nil {
		return errors.New("pakamsn")
	}
	//
	randomKey := userlib.RandomBytes(16)
	contentciphertext := userlib.SymEnc(randomKey, userlib.RandomBytes(16), contentjson)
	userlib.DatastoreSet(contentuuid, contentciphertext)
	userdata.addontoHMAC(headfilename, contentciphertext)
	if err != nil {
		return err
	}

	//Make a new UUID (keyuuid) based on a hash of the contentuuid
	keyuuid, err := uuid.FromBytes(userlib.Hash(contentuuid[:])[0:16])
	if err != nil {
		return err
	}
	//Make a new deterministic key with contentciphertext as the purpose and the user’s source key as the source key
	hashedusername := userlib.Hash([]byte(userdata.Username))
	hashedfilename := userlib.Hash([]byte(headfilename))
	hashedcombine := append(hashedusername, hashedfilename...)
	firstfileuuid, err := uuid.FromBytes(userlib.Hash(hashedcombine)[:16])
	if err != nil {
		return err
	}
	sourcekey, err := userdata.GetFileSourceKey(firstfileuuid)
	if err != nil {
		return err
	}
	determinkey, err := userlib.HashKDF(sourcekey, contentciphertext)
	if err != nil {
		return err
	}
	//Encrypt the randomly generated key using the deterministic key
	keyciphertext := userlib.SymEnc(determinkey[0:16], userlib.RandomBytes(16), randomKey)
	//Store the keyciphertext at keyuuid
	userlib.DatastoreSet(keyuuid, keyciphertext)
	return
}

func (userdata *User) UUIDLoadFile(firstfileuuid uuid.UUID, contentuuid uuid.UUID) (content []byte, err error) {
	//Make sure this file exists (meaning its UUID is being used)--> return error if it does not exist
	//Fetch encrypted file from contentUUID in Datastore
	contentciphertext, ok := userlib.DatastoreGet(contentuuid)
	if !ok {
		return nil, errors.New(strings.ToTitle("file not found"))
	}
	//Hash & slice contentuuid to generate the randomly generated key (RGK) UUID
	keyuuid, err := uuid.FromBytes(userlib.Hash(contentuuid[:])[0:16])
	if err != nil {
		return nil, err
	}
	//Fetch the encrypted RGK from Datastore
	RGkeyciphertext, ok := userlib.DatastoreGet(keyuuid)
	if len(RGkeyciphertext) != 32 {
		return nil, errors.New("ERRORMSG: key CT tampered with")
	}
	if !(ok) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff tbtb")
		return nil, err
	}
	sourcekey, err := userdata.GetFileSourceKey(firstfileuuid)
	if err != nil {
		return nil, err
	}
	determinkey, err := userlib.HashKDF(sourcekey, contentciphertext)
	if err != nil {
		return nil, err
	}
	//Decrypt RGK
	randgenkey := userlib.SymDec(determinkey[:16], RGkeyciphertext)
	if len(randgenkey) != 16 {
		return nil, errors.New("ERRORMSG: key tampered with")
	}

	//Decrypt file using RGK
	contentjson := userlib.SymDec(randgenkey[:16], contentciphertext)
	//Unmarshall the data to get the content
	err = json.Unmarshal(contentjson, &content)
	if err != nil {
		return nil, errors.New("maoslspsp")
	}
	//Check if there is any content at the following UUID
	//generate the next UUID as a Hash( Hash(UUID1) || Hash(“append”) ) [:16]
	nextuuid, err := GeneratetheUUIDofwhereweappendtonext(contentuuid, sourcekey)
	if err != nil {
		return nil, err
	}

	if fileexistshere(nextuuid) {
		nextfilecontent, err := userdata.UUIDLoadFile(firstfileuuid, nextuuid)
		if err != nil {
			return nil, err
		}
		content = append(content, nextfilecontent...)
	}
	return content, err
}

func (userdata *User) GenerateNewHMAC(firstfilename string) (MACofciphertext []byte, err error) {
	//Regenerate the first file’s UUID
	hashedusername := userlib.Hash([]byte(userdata.Username))
	hashedfilename := userlib.Hash([]byte(firstfilename))
	hashedcombine := append(hashedusername, hashedfilename...)
	firstfileuuid, err := uuid.FromBytes(userlib.Hash(hashedcombine)[:16])
	if err != nil {
		return nil, err
	}
	//Get the file’s RGK
	//Hash & slice contentuuid to generate the randomly generated key (RGK) UUID
	keyuuid, err := uuid.FromBytes(userlib.Hash(firstfileuuid[:])[0:16])
	if err != nil {
		return nil, err
	}
	//Fetch the encrypted RGK from Datastore
	RGkeyciphertext, ok := userlib.DatastoreGet(keyuuid)
	if !(ok) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff vrvr")
		return nil, err
	}
	//Regenerate the deterministic key
	contentciphertext, ok := userlib.DatastoreGet(firstfileuuid)
	if !(ok) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff djcbd")
		return nil, err
	}
	sourcekey, err := userdata.GetFileSourceKey(firstfileuuid)
	if err != nil {
		return nil, err
	}
	determinkey, err := userlib.HashKDF(sourcekey, contentciphertext)
	if err != nil {
		return nil, err
	}
	//Decrypt RGK
	randgenkey := userlib.SymDec(determinkey[:16], RGkeyciphertext)

	//Given a UUID, takes all the ciphertext from that UUID, HMAC it, then move on to HMAC any ciphertexts that are linked to it down the line
	// loop: append onto HMAC so far this file's ciphertext, then HMAC that and set it to HMACsofar
	thisfileUUID := firstfileuuid
	var HMACsofar []byte
	for {
		currentfileciphertext, ok := userlib.DatastoreGet(thisfileUUID)
		if !(ok) {
			break
		}
		HMACsofar = append(HMACsofar, currentfileciphertext...)
		HMACsofar, err = userlib.HMACEval(randgenkey, HMACsofar)
		if err != nil {
			return nil, err
		}
		//generate the next UUID as a Hash( Hash(UUID1) || Hash(“append”) ) [:16]
		nextuuid, err := GeneratetheUUIDofwhereweappendtonext(thisfileUUID, sourcekey)
		if err != nil {
			return nil, err
		}
		thisfileUUID = nextuuid
	}

	return HMACsofar, err
}

func (userdata *User) addontoHMAC(firstfilename string, newcontentciphertext []byte) error {
	//Generate the UUID that this file saves its HMAC at. It should be “Hash( Hash(hashedcombine) || Hash("MAC") || Hash(contentciphertext)”
	hashedusername := userlib.Hash([]byte(userdata.Username))
	hashedfilename := userlib.Hash([]byte(firstfilename))
	hashedcombine := append(hashedusername, hashedfilename...)
	firstfileuuid, err := uuid.FromBytes(userlib.Hash(hashedcombine)[:16])
	if err != nil {
		return err
	}
	contentciphertext, ok := userlib.DatastoreGet(firstfileuuid)
	if !(ok) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff vrvrv")
		return err
	}
	hashedMAC := userlib.Hash([]byte("MAC"))
	hashedciphertext := userlib.Hash(contentciphertext)
	hashedcombineMAC := append(hashedcombine, hashedMAC...)
	hashedcombineMAC = append(hashedcombineMAC, hashedciphertext...)
	hashuuid, err := uuid.FromBytes(userlib.Hash(hashedcombineMAC)[:16])
	if err != nil {
		return err
	}
	//Download the HMAC already there→ lets call it oldHMAC
	oldHMAC, ok := userlib.DatastoreGet(hashuuid)
	if !(ok) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff hhhh")
		return err
	}
	//Get the file’s RGK
	//Hash & slice contentuuid to generate the randomly generated key (RGK) UUID
	keyuuid, err := uuid.FromBytes(userlib.Hash(firstfileuuid[:])[0:16])
	if err != nil {
		return err
	}
	//Fetch the encrypted RGK from Datastore
	RGkeyciphertext, ok := userlib.DatastoreGet(keyuuid)
	if !(ok) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff aaaa")
		return err
	}
	//Regenerate the deterministic key
	sourcekey, err := userdata.GetFileSourceKey(firstfileuuid)
	if err != nil {
		return err
	}
	determinkey, err := userlib.HashKDF(sourcekey, contentciphertext)
	if err != nil {
		return err
	}
	//Decrypt RGK
	randgenkey := userlib.SymDec(determinkey[:16], RGkeyciphertext)
	// Reupload HMAC(RGK, oldHMAC || [ciphertext of most recent append]) to that same UUID
	newHMACinput := append(oldHMAC, newcontentciphertext...)
	newHMAC, err := userlib.HMACEval(randgenkey, newHMACinput)
	if err != nil {
		return err
	}
	userlib.DatastoreSet(hashuuid, newHMAC)

	return nil
}

// Sharing functions

func (userdata *User) StoreInviteFile(filename string, inviteuuid uuid.UUID, invitejson []byte) (err error) {
	contentjson, err := json.Marshal(invitejson)
	if err != nil {
		return errors.New("amlsmssp")
	}
	randomKey := userlib.RandomBytes(16)
	contentciphertext := userlib.SymEnc(randomKey, userlib.RandomBytes(16), contentjson)
	userlib.DatastoreSet(inviteuuid, contentciphertext)
	//HMAC the encrypted data using the same randomly generated key
	MACofcontentciphertext, err := userlib.HMACEval(randomKey, contentciphertext)
	if err != nil {
		return err
	}
	//Make hashedcombine
	hashedusername := userlib.Hash([]byte(userdata.Username))
	hashedfilename := userlib.Hash([]byte(filename))
	hashedcombine := append(hashedusername, hashedfilename...)
	// Store the MAC of the contentciphertext at a UUID which is from the bytes of Hash( Hash(hashedcombine) || Hash("MAC") )
	// Hash(Hash(username) || Hash(filename)) --> hashcombine
	// Hash(Hash( Hash(username) || Hash(filename) ) || Hash("MAC") || Hash(contentciphertext)) --> UUID where we save the MAC of contentciphertext
	hashedMAC := userlib.Hash([]byte("MAC"))
	hashedciphertext := userlib.Hash(contentciphertext)
	hashedcombineMAC := append(hashedcombine, hashedMAC...)
	hashedcombineMAC = append(hashedcombineMAC, hashedciphertext...)
	hashuuid, err := uuid.FromBytes(userlib.Hash(hashedcombineMAC)[:16])
	if err != nil {
		return err
	}
	userlib.DatastoreSet(hashuuid, MACofcontentciphertext)

	//Make a new UUID (keyuuid) based on a hash of the contentuuid
	keyuuid, err := uuid.FromBytes(userlib.Hash(inviteuuid[:])[0:16])
	if err != nil {
		return err
	}
	//Make a new deterministic key with contentciphertext as the purpose and the user’s source key as the source key
	err = userdata.StoreFileSourceKey(inviteuuid)
	if err != nil {
		return err
	}
	sourcekey, err := userdata.GetFileSourceKey(inviteuuid)
	if err != nil {
		return err
	}
	determinkey, err := userlib.HashKDF(sourcekey, contentciphertext)
	if err != nil {
		return err
	}
	//Encrypt the randomly generated key using the deterministic key
	keyciphertext := userlib.SymEnc(determinkey[0:16], userlib.RandomBytes(16), randomKey)
	//Store the keyciphertext at keyuuid
	userlib.DatastoreSet(keyuuid, keyciphertext)
	return
}

func (userdata *User) LoadSharedFile(invitefileuuid uuid.UUID) (content []byte, err error) {
	invitejson, err := userdata.UUIDLoadFile(invitefileuuid, invitefileuuid)
	if err != nil {
		return nil, err
	}
	var invite InviteInfo
	inviteptr := &invite
	err = json.Unmarshal(invitejson, inviteptr)
	if err != nil {
		return nil, errors.New("plplwpw")
	}
	return userdata.UUIDLoadSharedFile(invite.ContentUUID, invite.SourceKeyForthefile)
}

func (userdata *User) UUIDLoadSharedFile(contentuuid uuid.UUID, sourcekey []byte) (content []byte, err error) {
	//Fetch encrypted file from contentUUID in Datastore
	contentciphertext, ok := userlib.DatastoreGet(contentuuid)
	if !ok {
		return nil, errors.New(strings.ToTitle("file not found"))
	}
	//Hash & slice contentuuid to generate the randomly generated key (RGK) UUID
	keyuuid, err := uuid.FromBytes(userlib.Hash(contentuuid[:])[0:16])
	if err != nil {
		return nil, err
	}
	//Fetch the encrypted RGK from Datastore
	RGkeyciphertext, ok := userlib.DatastoreGet(keyuuid)
	if len(RGkeyciphertext) != 32 {
		return nil, errors.New("ERRORMSG: key CT tampered with")
	}
	if !(ok) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff rrrrr")
		return nil, err
	}
	//sourcekey provided in input by invite struct
	determinkey, err := userlib.HashKDF(sourcekey, contentciphertext)
	if err != nil {
		return nil, errors.New("sourcekey is not correct size")
	}
	//Decrypt RGK
	randgenkey := userlib.SymDec(determinkey[:16], RGkeyciphertext)
	if len(randgenkey) != 16 {
		return nil, errors.New("ERRORMSG: key tampered with")
	}

	//Decrypt file using RGK
	contentjson := userlib.SymDec(randgenkey[:16], contentciphertext)
	//Unmarshall the data to get the content
	err = json.Unmarshal(contentjson, &content)
	if err != nil {
		return nil, err
	}
	//Check if there is any content at the following UUID
	//generate the next UUID as a Hash( Hash(UUID1) || Hash(“append”) ) [:16]
	nextuuid, err := GeneratetheUUIDofwhereweappendtonext(contentuuid, sourcekey)
	if err != nil {
		return nil, err
	}

	_, ok = userlib.DatastoreGet(nextuuid)
	if ok {
		nextfilecontent, err := userdata.UUIDLoadSharedFile(nextuuid, sourcekey)
		if err != nil {
			return nil, err
		}
		content = append(content, nextfilecontent...)
	}
	return content, err
}

func (userdata *User) AppendtoSharedFile(invitefileuuid uuid.UUID, content []byte) error {
	invitejson, err := userdata.UUIDLoadFile(invitefileuuid, invitefileuuid)
	if err != nil {
		return err
	}
	var invite InviteInfo
	inviteptr := &invite
	err = json.Unmarshal(invitejson, inviteptr)
	if err != nil {
		return errors.New("kalsjs")
	}
	return userdata.UUIDAppendtoSharedFile(invite, content)
}

func (userdata *User) UUIDAppendtoSharedFile(invite InviteInfo, content []byte) error {
	// Regenerate the UUID where we save the UUID that we're going to append to
	UUIDwherewesavetheUUID, err := GeneratetheUUIDofwherewesavetheUUID(invite.ContentUUID, invite.SourceKeyForthefile)

	if err != nil {
		return err
	}
	// get the encrypted UUID from UUIDwherewesavetheUUID
	encryptednextUUID, ok := userlib.DatastoreGet(UUIDwherewesavetheUUID)
	if !(ok) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff ttt")
		return err
	}
	// Regenerate the key we encrypted encryptednextUUID with
	sourcekey := invite.SourceKeyForthefile
	if err != nil {
		return err
	}
	nextUUIDkey, err := userlib.HashKDF(sourcekey, invite.ContentUUID[:])
	if err != nil {
		return err
	}
	// decrypt nextUUID
	nextUUID, err := uuid.FromBytes(userlib.SymDec(nextUUIDkey[:16], encryptednextUUID))
	if err != nil {
		return err
	}
	// Call some storefile on content to nextUUID
	userdata.UUIDStoreSharedFile(nextUUID, content, invite)

	// Update the contents stored at UUIDwherewesavetheUUID
	nextnextUUID, err := GeneratetheUUIDofwhereweappendtonext(nextUUID, sourcekey)
	if err != nil {
		return err
	}
	// Step 2: encrypt the nextUUID through a deterministic key based on the user's source key and headfile's UUID
	nextnextUUIDciphertext := userlib.SymEnc(nextUUIDkey[0:16], userlib.RandomBytes(16), nextnextUUID[:])
	userlib.DatastoreSet(UUIDwherewesavetheUUID, nextnextUUIDciphertext[:])

	return nil
}

func (userdata *User) UUIDStoreSharedFile(contentuuid uuid.UUID, content []byte, invite InviteInfo) error {
	// Marshall the data
	contentjson, err := json.Marshal(content)
	if err != nil {
		return errors.New("qlspwpw")
	}
	//
	randomKey := userlib.RandomBytes(16)
	contentciphertext := userlib.SymEnc(randomKey, userlib.RandomBytes(16), contentjson)
	userlib.DatastoreSet(contentuuid, contentciphertext)
	err = userdata.addontoHMACofSharedFile(invite, contentciphertext)
	if err != nil {
		return err
	}

	//Make a new UUID (keyuuid) based on a hash of the contentuuid
	keyuuid, err := uuid.FromBytes(userlib.Hash(contentuuid[:])[0:16])
	if err != nil {
		return err
	}
	//Make a new deterministic key with contentciphertext as the purpose and the user’s source key as the source key
	//just made a chage here 8:44 PM
	sourcekey := invite.SourceKeyForthefile
	if err != nil {
		return err
	}
	determinkey, err := userlib.HashKDF(sourcekey, contentciphertext)
	if err != nil {
		return err
	}
	//Encrypt the randomly generated key using the deterministic key
	keyciphertext := userlib.SymEnc(determinkey[0:16], userlib.RandomBytes(16), randomKey)
	//Store the keyciphertext at keyuuid
	userlib.DatastoreSet(keyuuid, keyciphertext)
	return nil
}

func (userdata *User) addontoHMACofSharedFile(invite InviteInfo, newcontentciphertext []byte) error {
	//Generate the UUID that this file saves its HMAC at.
	contentciphertext, ok := userlib.DatastoreGet(invite.ContentUUID)
	if !(ok) {
		err := errors.New("something went wrong. We suspect someone is trying to mess with stuff zzz")
		return err
	}
	hashedMAC := userlib.Hash([]byte("MAC"))
	hashedciphertext := userlib.Hash(contentciphertext)
	hashedcombine := gethashedcombine(invite)
	hashedcombineMAC := append(hashedcombine, hashedMAC...)
	hashedcombineMAC = append(hashedcombineMAC, hashedciphertext...)
	hashuuid, err := uuid.FromBytes(userlib.Hash(hashedcombineMAC)[:16])
	if err != nil {
		return err
	}
	//Download the HMAC already there→ lets call it oldHMAC
	oldHMAC, ok := userlib.DatastoreGet(hashuuid)
	if !(ok) {
		userlib.DatastoreSet(hashuuid, nil)
	}
	//Get the file’s RGK
	//Hash & slice contentuuid to generate the randomly generated key (RGK) UUID
	keyuuid, err := uuid.FromBytes(userlib.Hash(invite.ContentUUID[:])[0:16])
	if err != nil {
		return err
	}
	//Fetch the encrypted RGK from Datastore
	RGkeyciphertext, ok := userlib.DatastoreGet(keyuuid)
	if !(ok) {
		err = errors.New("something went wrong. We suspect someone is trying to mess with stuff alal")
		return err
	}
	//Regenerate the deterministic key
	sourcekey := invite.SourceKeyForthefile
	if err != nil {
		return err
	}
	determinkey, err := userlib.HashKDF(sourcekey, contentciphertext)
	if err != nil {
		return err
	}
	//Decrypt RGK
	randgenkey := userlib.SymDec(determinkey[:16], RGkeyciphertext)
	// Reupload HMAC(RGK, oldHMAC || [ciphertext of most recent append]) to that same UUID
	newHMACinput := append(oldHMAC, newcontentciphertext...)
	newHMAC, err := userlib.HMACEval(randgenkey, newHMACinput)
	if err != nil {
		return err
	}
	userlib.DatastoreSet(hashuuid, newHMAC)
	return nil
}

func (userdata *User) CreateInvitationforaSharedFile(filename string, recipientUsername string) (invitationPtr uuid.UUID, err error) {
	//Regenerate hashedcombine
	hashedusername := userlib.Hash([]byte(userdata.Username))
	hashedfilename := userlib.Hash([]byte(filename))
	hashedcombine := append(hashedusername, hashedfilename...)
	// check if this is a shared file
	hashedinvitedstring := userlib.Hash([]byte("invited"))
	hashedcombineinvite := append(hashedcombine, hashedinvitedstring...)
	invitefileuuid, _ := uuid.FromBytes(userlib.Hash(hashedcombineinvite)[:16])
	// Step 1: get our invite info struct in here so we have al the info we need to share
	invitejson, err := userdata.UUIDLoadFile(invitefileuuid, invitefileuuid)
	if err != nil {
		return uuid.Nil, err
	}
	var invite InviteInfo
	inviteptr := &invite
	err = json.Unmarshal(invitejson, inviteptr)
	if err != nil {
		return uuid.Nil, err
	}
	// Step 2: share this same invite with the new guy (all the attributes turn out to be the same)
	// STEP 2A: marshall then encrypt the invite info using some symmetric key
	jsoninvitedata, err := json.Marshal(invite)
	if err != nil {
		return uuid.Nil, err
	}
	recipientPK, ok := userlib.KeystoreGet(recipientUsername + "/publickey")
	if !(ok) {
		return uuid.Nil, errors.New("no user receipient found")
	}
	randomkey := userlib.RandomBytes(16)
	invitedataciphertext := userlib.SymEnc(randomkey, userlib.RandomBytes(16), jsoninvitedata)
	randomkeyciphertext, err := userlib.PKEEnc(recipientPK, randomkey)
	if err != nil {
		return uuid.Nil, err
	}
	// STEP 3: make a invite with sig struct
	var invitewithsig InvitewithSig
	invitewithsig.Alltheinfo = invitedataciphertext
	invitewithsig.Sig, err = userlib.DSSign(userdata.SignKey, invitedataciphertext)
	if err != nil {
		return uuid.Nil, err
	}
	invitewithsig.SymKeyCiphertext = randomkeyciphertext
	// STEP 4: marshal that, store it to some random UUID, and return the rando UUID
	jsoninvitewithsig, err := json.Marshal(invitewithsig)
	if err != nil {
		return uuid.Nil, errors.New("lapalpapa")
	}
	invitationPtr = uuid.New()
	userlib.DatastoreSet(invitationPtr, jsoninvitewithsig)
	return invitationPtr, err
}

func (userdata *User) StoreSharedFile(filename string, content []byte) error {
	userdata.clearthisSharedfile(filename)
	// generate the invite file
	// get the invitefileuuid
	hashedusername := userlib.Hash([]byte(userdata.Username))
	hashedfilename := userlib.Hash([]byte(filename))
	hashedcombine := append(hashedusername, hashedfilename...)
	//
	hashedinvitedstring := userlib.Hash([]byte("invited"))
	hashedcombineinvite := append(hashedcombine, hashedinvitedstring...)
	invitefileuuid, _ := uuid.FromBytes(userlib.Hash(hashedcombineinvite)[:16])
	invitejson, err := userdata.UUIDLoadFile(invitefileuuid, invitefileuuid)
	if err != nil {
		return err
	}
	var invite InviteInfo
	inviteptr := &invite
	err = json.Unmarshal(invitejson, inviteptr)
	if err != nil {
		return err
	}
	//copy process from store file
	//Make a UUID (from now on called UUID1) based on the user and file name
	contentuuid := invite.ContentUUID

	if err != nil {
		return err
	}
	// Marshall the data
	contentjson, err := json.Marshal(content)
	if err != nil {
		return errors.New("ebjc")
	}
	//Store the contents at contentuuid using a randomly generated key
	randomKey := userlib.RandomBytes(16)
	contentciphertext := userlib.SymEnc(randomKey, userlib.RandomBytes(16), contentjson)
	userlib.DatastoreSet(contentuuid, contentciphertext)
	if err != nil {
		return err
	}
	//HMAC the encrypted data using the same randomly generated key
	MACofcontentciphertext, err := userlib.HMACEval(randomKey, contentciphertext)
	if err != nil {
		return err
	}

	// Store the MAC of the contentciphertext at a UUID which is from the bytes of Hash( Hash(hashedcombine) || Hash("MAC") )
	// Hash(Hash(username) || Hash(filename)) --> hashcombine
	// Hash(Hash( Hash(username) || Hash(filename) ) || Hash("MAC") || Hash(contentciphertext)) --> UUID where we save the MAC of contentciphertext
	hashedMAC := userlib.Hash([]byte("MAC"))
	hashedciphertext := userlib.Hash(contentciphertext)
	// just made this hashedcombine edit
	hashedcombine = gethashedcombine(invite)
	hashedcombineMAC := append(hashedcombine, hashedMAC...)
	hashedcombineMAC = append(hashedcombineMAC, hashedciphertext...)
	hashuuid, err := uuid.FromBytes(userlib.Hash(hashedcombineMAC)[:16])
	if err != nil {
		return err
	}
	userlib.DatastoreSet(hashuuid, MACofcontentciphertext)

	//Make a new UUID (keyuuid) based on a hash of the contentuuid
	keyuuid, err := uuid.FromBytes(userlib.Hash(contentuuid[:])[0:16])
	if err != nil {
		return err
	}
	//Make a new deterministic key with contentciphertext as the purpose and the user’s source key as the source key
	sourcekey := invite.SourceKeyForthefile
	determinkey, err := userlib.HashKDF(sourcekey, contentciphertext)
	if err != nil {
		return err
	}
	if sourcekey == nil {
		return errors.New("source keys not being saved for some reason jcnc")
	}
	//Encrypt the randomly generated key using the deterministic key
	keyciphertext := userlib.SymEnc(determinkey[0:16], userlib.RandomBytes(16), randomKey)
	//Store the keyciphertext at keyuuid
	userlib.DatastoreSet(keyuuid, keyciphertext)

	//save the next available UUID to append to
	// Step 1: Generate the UUID for where we're gonna save the next avaible UUID
	UUIDwherewesavetheUUID, err := GeneratetheUUIDofwherewesavetheUUID(invite.ContentUUID, sourcekey)
	if err != nil {
		return err
	}
	// Step 2: Generate the UUID where we'd append to next
	nextuuid, err := GeneratetheUUIDofwhereweappendtonext(contentuuid, sourcekey)
	if err != nil {
		return err
	}
	// Step 3: encrypt the nextUUID through a deterministic key based on the user's source key and headfile's UUID
	nextUUIDkey, err := userlib.HashKDF(sourcekey, contentuuid[:])
	if err != nil {
		return err
	}
	nextUUIDciphertext := userlib.SymEnc(nextUUIDkey[0:16], userlib.RandomBytes(16), nextuuid[:])
	// Step 4: save nextuuidciphertext to UUIDwherewesavetheUUID
	userlib.DatastoreSet(UUIDwherewesavetheUUID, nextUUIDciphertext)

	return nil
}

func (userdata *User) thisFileWasSharedWithUs(filename string) bool {
	//Regenerate hashedcombine
	hashedusername := userlib.Hash([]byte(userdata.Username))
	hashedfilename := userlib.Hash([]byte(filename))
	hashedcombine := append(hashedusername, hashedfilename...)
	// check if this is a shared file
	hashedinvitedstring := userlib.Hash([]byte("invited"))
	hashedcombineinvite := append(hashedcombine, hashedinvitedstring...)
	inviteuuid, _ := uuid.FromBytes(userlib.Hash(hashedcombineinvite)[:16])
	_, ok := userlib.DatastoreGet(inviteuuid)
	if ok {
		return true
	} else {
		return false
	}
}

func (userdata *User) clearthisSharedfile(filename string) error {
	// generate file uuid
	// get the invitefileuuid
	hashedusername := userlib.Hash([]byte(userdata.Username))
	hashedfilename := userlib.Hash([]byte(filename))
	hashedcombine := append(hashedusername, hashedfilename...)
	//
	hashedinvitedstring := userlib.Hash([]byte("invited"))
	hashedcombineinvite := append(hashedcombine, hashedinvitedstring...)
	invitefileuuid, _ := uuid.FromBytes(userlib.Hash(hashedcombineinvite)[:16])
	invitejson, err := userdata.UUIDLoadFile(invitefileuuid, invitefileuuid)
	if err != nil {
		return err
	}
	var invite InviteInfo
	inviteptr := &invite
	err = json.Unmarshal(invitejson, inviteptr)
	if err != nil {
		return err
	}
	// delete where it stores its mac
	hashedMAC := userlib.Hash([]byte("MAC"))
	contentciphertext, ok := userlib.DatastoreGet(invite.ContentUUID)
	if !(ok) {
		return errors.New("clearing trouble")
	}
	hashedcombine = gethashedcombine(invite)
	hashedciphertext := userlib.Hash(contentciphertext)
	hashedcombineMAC := append(hashedcombine, hashedMAC...)
	hashedcombineMAC = append(hashedcombineMAC, hashedciphertext...)
	hashuuid, err := uuid.FromBytes(userlib.Hash(hashedcombineMAC)[:16])
	userlib.DatastoreDelete(hashuuid)
	if err != nil {
		return err
	}
	// delete its UUIDwherewesavetheUUID
	UUIDwherewesavetheUUID, err := GeneratetheUUIDofwherewesavetheUUID(invite.ContentUUID, invite.SourceKeyForthefile)
	if err != nil {
		return err
	}
	userlib.DatastoreDelete(UUIDwherewesavetheUUID)
	// delete it and all its appendages
	thisfileUUID := invite.ContentUUID
	sourcekey := invite.SourceKeyForthefile
	for {
		_, ok := userlib.DatastoreGet(thisfileUUID)
		if !(ok) {
			break
		}
		userlib.DatastoreDelete(thisfileUUID)
		//delete the keyuuids
		keyuuid, err := uuid.FromBytes(userlib.Hash(thisfileUUID[:])[0:16])
		if err != nil {
			return err
		}
		_, ok = userlib.DatastoreGet(keyuuid)
		if !(ok) {
			break
		}
		userlib.DatastoreDelete(keyuuid)
		//generate the next UUID as a Hash( Hash(UUID1) || Hash(“append”) ) [:16]
		nextuuid, err := GeneratetheUUIDofwhereweappendtonext(thisfileUUID, sourcekey)
		if err != nil {
			return err
		}
		thisfileUUID = nextuuid
	}
	return nil
}

// Source key functions

func (userdata *User) StoreFileSourceKey(headfileuuid uuid.UUID) (err error) {
	//make a new UUID to store the source key at a uuid related to the headfileuuid
	hashedsourcekey := userlib.Hash([]byte("source key"))
	hashedheadfileuuid := userlib.Hash(headfileuuid[:])
	hashedcombinekey := append(hashedsourcekey, hashedheadfileuuid...)
	hashedcombinekey = userlib.Hash(hashedcombinekey)
	onemorefunhash := userlib.Hash([]byte("it would be really hard to just make up a uuid that was used here"))
	hashedcombinekey = append(hashedcombinekey, onemorefunhash...)
	hashedcombinekey = userlib.Hash(hashedcombinekey)
	sourcekeyuuid, err := uuid.FromBytes(userlib.Hash(hashedcombinekey)[:16])
	if err != nil {
		return err
	}
	//make a file sourcekey, encrypt it with users source key encryptor, and save it to that wackadoo uuid
	filesourcekey := userlib.RandomBytes(16)
	sourcekeyciphertext := userlib.SymEnc(userdata.SourcekeyEncryptor, userlib.RandomBytes(16), filesourcekey)
	userlib.DatastoreSet(sourcekeyuuid, sourcekeyciphertext)
	return nil
}

func (userdata *User) GetFileSourceKey(headfileuuid uuid.UUID) (sourcekey []byte, err error) {
	//regenerate sourcekeyuuid
	hashedsourcekey := userlib.Hash([]byte("source key"))
	hashedheadfileuuid := userlib.Hash(headfileuuid[:])
	hashedcombinekey := append(hashedsourcekey, hashedheadfileuuid...)
	hashedcombinekey = userlib.Hash(hashedcombinekey)
	onemorefunhash := userlib.Hash([]byte("it would be really hard to just make up a uuid that was used here"))
	hashedcombinekey = append(hashedcombinekey, onemorefunhash...)
	hashedcombinekey = userlib.Hash(hashedcombinekey)
	sourcekeyuuid, err := uuid.FromBytes(userlib.Hash(hashedcombinekey)[:16])
	if err != nil {
		return nil, err
	}
	//get the ct, decrypt it, return
	filesourcekeyciphertext, ok := userlib.DatastoreGet(sourcekeyuuid)
	if !ok {
		return nil, errors.New("source key not in the right spot")
	}
	filesourcekey := userlib.SymDec(userdata.SourcekeyEncryptor, filesourcekeyciphertext)
	return filesourcekey, nil
}

func gethashedcombine(invite InviteInfo) (hashedcombineresult []byte) {
	hashedusername := userlib.Hash([]byte(invite.Fileownerusername))
	hashedfilename := userlib.Hash([]byte(invite.Creatorsheadfilename))
	return append(hashedusername, hashedfilename...)
}

func GeneratetheUUIDofwhereweappendtonext(contentuuid uuid.UUID, sourcekey []byte) (nextUUID uuid.UUID, err error) {
	hashuuid1 := userlib.Hash(contentuuid[:])
	hashappend := userlib.Hash([]byte("append"))
	hashsourcekey := userlib.Hash(sourcekey)
	hashuuid1 = append(hashuuid1, hashappend...)
	hashuuid1 = append(hashuuid1, hashsourcekey...)
	nextuuid, err := uuid.FromBytes(userlib.Hash(hashuuid1)[:16])
	if err != nil {
		return uuid.Nil, err
	}
	return nextuuid, nil
}

func GeneratetheUUIDofwherewesavetheUUID(contentuuid uuid.UUID, sourcekey []byte) (UUIDwherewesavetheUUID uuid.UUID, err error) {
	keyuuid, err := uuid.FromBytes(userlib.Hash(contentuuid[:])[0:16])
	if err != nil {
		return uuid.Nil, err
	}
	tobehashed := userlib.Hash(keyuuid[:][0:16])
	tobehashed = append(tobehashed, userlib.Hash([]byte("next available append position"))...)
	tobehashed = append(tobehashed, userlib.Hash(sourcekey)...)
	return uuid.FromBytes(userlib.Hash(tobehashed)[0:16])
}
