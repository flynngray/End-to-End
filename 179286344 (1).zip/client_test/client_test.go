package client_test

// You MUST NOT change these default imports.  ANY additional imports may
// break the autograder and everyone will be sad.

import (
	// Some imports use an underscore to prevent the compiler from complaining
	// about unused imports.
	_ "encoding/hex"
	_ "errors"
	"fmt"
	_ "fmt"
	_ "strconv"
	_ "strings"
	"testing"

	// A "dot" import is used here so that the functions in the ginko and gomega
	// modules can be used without an identifier. For example, Describe() and
	// Expect() instead of ginko.Describe() and gomega.Expect().

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"

	userlib "github.com/cs161-staff/project2-userlib"

	"github.com/cs161-staff/project2-starter-code/client"
)

func TestSetupAndExecution(t *testing.T) {
	RegisterFailHandler(Fail)
	RunSpecs(t, "Client Tests")
}

// ================================================
// Global Variables (feel free to add more!)
// ================================================
const defaultPassword = "password"
const emptyString = ""
const contentOne = "Bitcoin is Nick's favorite "
const contentTwo = "digital "
const contentThree = "cryptocurrency!"

// ================================================
// Describe(...) blocks help you organize your tests
// into functional categories. They can be nested into
// a tree-like structure.
// ================================================

var _ = Describe("Client Tests", func() {

	// A few user declarations that may be used for testing. Remember to initialize these before you
	// attempt to use them!
	var alice *client.User
	var bob *client.User
	var charles *client.User
	// var doris *client.User
	// var eve *client.User
	// var frank *client.User
	// var grace *client.User
	// var horace *client.User
	// var ira *client.User

	// These declarations may be useful for multi-session testing.
	var alicePhone *client.User
	var aliceLaptop *client.User
	var aliceDesktop *client.User

	var err error

	// A bunch of filenames that may be useful.
	aliceFile := "aliceFile.txt"
	bobFile := "bobFile.txt"
	charlesFile := "charlesFile.txt"
	// dorisFile := "dorisFile.txt"
	// eveFile := "eveFile.txt"
	// frankFile := "frankFile.txt"
	// graceFile := "graceFile.txt"
	// horaceFile := "horaceFile.txt"
	// iraFile := "iraFile.txt"

	BeforeEach(func() {
		// This runs before each test within this Describe block (including nested tests).
		// Here, we reset the state of Datastore and Keystore so that tests do not interfere with each other.
		// We also initialize
		userlib.DatastoreClear()
		userlib.KeystoreClear()
	})

	Describe("Basic Tests", func() {

		Specify("Basic Test: Testing InitUser/GetUser on a single user.", func() {
			userlib.DebugMsg("Initializing user Alice.")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Getting user Alice.")
			aliceLaptop, err = client.GetUser("alice", defaultPassword)
			Expect(err).To(BeNil())
		})

		Specify("Basic Test: Testing Single User Store/Load/Append.", func() {
			userlib.DebugMsg("Initializing user Alice.")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Storing file data: %s", contentOne)
			err = alice.StoreFile(aliceFile, []byte(contentOne))
			Expect(err).To(BeNil())

			userlib.DebugMsg("Appending file data: %s", contentTwo)
			err = alice.AppendToFile(aliceFile, []byte(contentTwo))
			Expect(err).To(BeNil())

			userlib.DebugMsg("Appending file data: %s", contentThree)
			err = alice.AppendToFile(aliceFile, []byte(contentThree))
			Expect(err).To(BeNil())

			userlib.DebugMsg("Loading file...")
			data, err := alice.LoadFile(aliceFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne + contentTwo + contentThree)))
		})

		Specify("Basic Test: Testing Create/Accept Invite Functionality with multiple users and multiple instances.", func() {
			userlib.DebugMsg("Initializing users Alice (aliceDesktop) and Bob.")
			aliceDesktop, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Getting second instance of Alice - aliceLaptop")
			aliceLaptop, err = client.GetUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("aliceDesktop storing file %s with content: %s", aliceFile, contentOne)
			err = aliceDesktop.StoreFile(aliceFile, []byte(contentOne))
			Expect(err).To(BeNil())

			userlib.DebugMsg("aliceLaptop creating invite for Bob.")
			invite, err := aliceLaptop.CreateInvitation(aliceFile, "bob")
			Expect(err).To(BeNil())

			userlib.DebugMsg("Bob accepting invite from Alice under filename %s.", bobFile)
			err = bob.AcceptInvitation("alice", invite, bobFile)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Bob appending to file %s, content: %s", bobFile, contentTwo)
			err = bob.AppendToFile(bobFile, []byte(contentTwo))
			Expect(err).To(BeNil())

			userlib.DebugMsg("aliceDesktop appending to file %s, content: %s", aliceFile, contentThree)
			err = aliceDesktop.AppendToFile(aliceFile, []byte(contentThree))
			Expect(err).To(BeNil())

			userlib.DebugMsg("Checking that aliceDesktop sees expected file data.")
			data, err := aliceDesktop.LoadFile(aliceFile)
			fmt.Println("data: ", data)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne + contentTwo + contentThree)))

			userlib.DebugMsg("Checking that aliceLaptop sees expected file data.")
			data, err = aliceLaptop.LoadFile(aliceFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne + contentTwo + contentThree)))

			userlib.DebugMsg("Checking that Bob sees expected file data.")
			data, err = bob.LoadFile(bobFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne + contentTwo + contentThree)))

			userlib.DebugMsg("Getting third instance of Alice - alicePhone.")
			alicePhone, err = client.GetUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Checking that alicePhone sees Alice's changes.")
			data, err = alicePhone.LoadFile(aliceFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne + contentTwo + contentThree)))
		})

		Specify("Basic Test: Testing Revoke Functionality", func() {
			userlib.DebugMsg("Initializing users Alice, Bob, and Charlie.")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())

			charles, err = client.InitUser("charles", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Alice storing file %s with content: %s", aliceFile, contentOne)
			alice.StoreFile(aliceFile, []byte(contentOne))

			userlib.DebugMsg("Alice creating invite for Bob for file %s, and Bob accepting invite under name %s.", aliceFile, bobFile)

			invite, err := alice.CreateInvitation(aliceFile, "bob")
			Expect(err).To(BeNil())

			err = bob.AcceptInvitation("alice", invite, bobFile)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Checking that Alice can still load the file.")
			data, err := alice.LoadFile(aliceFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne)))

			userlib.DebugMsg("Checking that Bob can load the file.")
			data, err = bob.LoadFile(bobFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne)))

			userlib.DebugMsg("Bob creating invite for Charles for file %s, and Charlie accepting invite under name %s.", bobFile, charlesFile)
			invite, err = bob.CreateInvitation(bobFile, "charles")
			Expect(err).To(BeNil())

			err = charles.AcceptInvitation("bob", invite, charlesFile)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Checking that Charles can load the file.")
			data, err = charles.LoadFile(charlesFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne)))

			userlib.DebugMsg("Alice revoking Bob's access from %s.", aliceFile)
			err = alice.RevokeAccess(aliceFile, "bob")
			Expect(err).To(BeNil())

			userlib.DebugMsg("Checking that Alice can still load the file.")
			data, err = alice.LoadFile(aliceFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne)))

			userlib.DebugMsg("Checking that Bob/Charles lost access to the file.")
			_, err = bob.LoadFile(bobFile)
			Expect(err).ToNot(BeNil())

			_, err = charles.LoadFile(charlesFile)
			Expect(err).ToNot(BeNil())

			userlib.DebugMsg("Checking that the revoked users cannot append to the file.")
			err = bob.AppendToFile(bobFile, []byte(contentTwo))
			Expect(err).ToNot(BeNil())

			err = charles.AppendToFile(charlesFile, []byte(contentTwo))
			Expect(err).ToNot(BeNil())
		})

	})
	Describe("More Tests", func() {
		Specify("InitUser: No repeat usernames", func() {
			userlib.DebugMsg("INITUSER MORE TESTS:")
			userlib.DebugMsg("Making sure no two users can have the same username")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			bob, err = client.InitUser("alice", defaultPassword)
			Expect(err).ToNot(BeNil())
		})
		Specify("InitUser: No empty usernames", func() {
			userlib.DebugMsg("Making sure no username can be empty")
			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())
			charles, err = client.InitUser("", defaultPassword)
			Expect(err).ToNot(BeNil())
			userlib.DebugMsg("INITUSER ERROR CASES PASSED")
		})

		Specify("GetUser: no initialized user for the given username", func() {
			userlib.DebugMsg("GETUSER MORE TESTS:")
			userlib.DebugMsg("Checking for no initialized user for the given username")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			bob, err = client.GetUser("alice2", defaultPassword)
			Expect(err).ToNot(BeNil())
		})

		Specify("GetUser: user credentials are invalid", func() {
			userlib.DebugMsg("Checking user credentials")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			bob, err = client.GetUser("alice", defaultPassword+"hi")
			Expect(err).ToNot(BeNil())
		})

		Specify("GetUser: The User struct cannot be obtained due to malicious action, or the integrity of the user struct has been compromised.", func() {
			userlib.DebugMsg("The User struct cannot be obtained due to malicious action, or the integrity of the user struct has been compromised.")
			bob, err = client.InitUser("flynn", defaultPassword)
			Expect(err).To(BeNil())
			for k := range userlib.DatastoreGetMap() {
				userlib.DatastoreGetMap()[k] = []byte("hi")
			}
			bob, err = client.GetUser("flynn", defaultPassword)
			Expect(err).ToNot(BeNil())
			userlib.DebugMsg("GETUSER ERROR CASES PASSED")
		})

		Specify("LoadFile: The given filename does not exist in the personal file namespace of the caller.", func() {
			userlib.DebugMsg("Loadfile: Checking for if the given filename does not exist in the personal file namespace of the caller. ")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			_, err := alice.LoadFile("hi")
			Expect(err).ToNot(BeNil())
		})

		Specify("StoreFile: files can be overwritten", func() {
			userlib.DebugMsg("Storefile: files can be overwritten")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			err = alice.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())
			err = alice.StoreFile("hi", []byte(contentTwo))
			Expect(err).To(BeNil())

			data, err := alice.LoadFile("hi")
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentTwo)))
		})

		Specify("Store/Append: Testing Single User Store/Load/Append.", func() {
			userlib.DebugMsg("Initializing user Alice.")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Storing file data: %s", contentOne)
			err = alice.StoreFile(aliceFile, []byte(contentOne))
			Expect(err).To(BeNil())

			userlib.DebugMsg("Appending file data: %s", contentTwo)
			err = alice.AppendToFile(aliceFile, []byte(contentTwo))
			Expect(err).To(BeNil())

			userlib.DebugMsg("Storing file data HEY HEY THIS IS THE TEST LOOK AT ME: %s", contentThree)
			err = alice.StoreFile(aliceFile, []byte(contentThree))
			Expect(err).To(BeNil())

			userlib.DebugMsg("Loading file...")
			data, err := alice.LoadFile(aliceFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentThree)))
		})

		Specify("LoadFile: The integrity of the downloaded content cannot be verified (indicating there have been unauthorized modifications to the file).", func() {
			userlib.DebugMsg("Loadfile: Checking if The integrity of the downloaded content cannot be verified (indicating there have been unauthorized modifications to the file).")
			alice, err = client.InitUser("alice", defaultPassword)
			ogdatastoremap := make(map[userlib.UUID][]byte)
			for k, v := range userlib.DatastoreGetMap() {
				ogdatastoremap[k] = v
			}
			//fmt.Println("PRE FILE SAVED, maplen: ", len(userlib.DatastoreGetMap()))
			/*for keyy, valuee := range userlib.DatastoreGetMap() {
				fmt.Println("Key:", keyy, "=>", "Element:", valuee)
			} */
			Expect(err).To(BeNil())
			err := alice.StoreFile("hi", []byte(contentOne))
			//fmt.Println("AND NOW WITH THE FILE SAVED, maplen: ", len(userlib.DatastoreGetMap()))
			/*for keyy, valuee := range userlib.DatastoreGetMap() {
				fmt.Println("Key:", keyy, "=>", "Element:", valuee)
			} */
			Expect(err).To(BeNil())
			for key := range userlib.DatastoreGetMap() {
				userlib.DatastoreGetMap()[key] = []byte(contentThree)
			}
			for key, value := range ogdatastoremap {
				userlib.DatastoreGetMap()[key] = value
			}
			_, err = alice.LoadFile("hi")
			Expect(err).ToNot(BeNil())
		})
		Specify("SHARING FILES BASIC LOAD FILE TEST", func() {
			userlib.DebugMsg("LOADING SHARED FILES, BASIC TEST")
			userlib.DebugMsg("Initializing users Alice (aliceDesktop) and Bob.")
			aliceDesktop, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("aliceDesktop storing file %s with content: %s", aliceFile, contentOne)
			err = aliceDesktop.StoreFile(aliceFile, []byte(contentOne))
			Expect(err).To(BeNil())

			userlib.DebugMsg("aliceDesktop creating invite for Bob.")
			invite, err := aliceDesktop.CreateInvitation(aliceFile, "bob")
			Expect(err).To(BeNil())

			userlib.DebugMsg("Bob accepting invite from Alice under filename %s.", bobFile)
			err = bob.AcceptInvitation("alice", invite, bobFile)
			Expect(err).To(BeNil())
			userlib.DebugMsg("Bob loading file %s.", bobFile)
			data, err := bob.LoadFile(bobFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne)))
		})

		Specify("SHARING FILES LOAD FILE TEST", func() {
			userlib.DebugMsg("LOADING SHARED FILES, MUILTPLE USER VERSIONS TEST")
			userlib.DebugMsg("Initializing users Alice (aliceDesktop) and Bob.")
			aliceDesktop, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Getting second instance of Alice - aliceLaptop")
			aliceLaptop, err = client.GetUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("aliceDesktop storing file %s with content: %s", aliceFile, contentOne)
			err = aliceDesktop.StoreFile(aliceFile, []byte(contentOne))
			Expect(err).To(BeNil())

			userlib.DebugMsg("aliceLaptop creating invite for Bob.")
			invite, err := aliceLaptop.CreateInvitation(aliceFile, "bob")
			Expect(err).To(BeNil())

			userlib.DebugMsg("Bob accepting invite from Alice under filename %s.", bobFile)
			err = bob.AcceptInvitation("alice", invite, bobFile)
			Expect(err).To(BeNil())
			userlib.DebugMsg("Bob loading file %s.", bobFile)
			data, err := bob.LoadFile(bobFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne)))
			fmt.Println()
		})

		Specify("SHARING FILES APPEND FILE TEST one instance per user", func() {
			userlib.DebugMsg("SHARING FILES APPEND FILE TEST one instance per user")
			aliceDesktop, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("alice storing file %s with content: %s", aliceFile, contentOne)
			err = aliceDesktop.StoreFile(aliceFile, []byte(contentOne))
			Expect(err).To(BeNil())

			userlib.DebugMsg("alice creating invite for Bob.")
			invite, err := aliceDesktop.CreateInvitation(aliceFile, "bob")
			Expect(err).To(BeNil())

			userlib.DebugMsg("Bob accepting invite from Alice under filename %s.", bobFile)
			err = bob.AcceptInvitation("alice", invite, bobFile)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Bob appending to file %s, content: %s", bobFile, contentTwo)
			err = bob.AppendToFile(bobFile, []byte(contentTwo))
			Expect(err).To(BeNil())
			userlib.DebugMsg("Bob loading file")
			data, err := bob.LoadFile(bobFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne + contentTwo)))
		})

		Specify("SHARING FILES STORE FILE TEST (Bob overwrites)", func() {
			userlib.DebugMsg("OVERWRITING SHARED FILES, MUILTPLE USER VERSIONS TEST (bob overwrites)")
			userlib.DebugMsg("Initializing users Alice (aliceDesktop) and Bob.")
			aliceDesktop, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Getting second instance of Alice - aliceLaptop")
			aliceLaptop, err = client.GetUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("aliceDesktop storing file %s with content: %s", aliceFile, contentOne)
			err = aliceDesktop.StoreFile(aliceFile, []byte(contentOne))
			Expect(err).To(BeNil())

			userlib.DebugMsg("aliceLaptop creating invite for Bob.")
			invite, err := aliceLaptop.CreateInvitation(aliceFile, "bob")
			Expect(err).To(BeNil())

			userlib.DebugMsg("Bob accepting invite from Alice under filename %s.", bobFile)
			err = bob.AcceptInvitation("alice", invite, bobFile)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Bob overwriting file %s.", bobFile)
			err = bob.StoreFile(bobFile, []byte(contentTwo))
			Expect(err).To(BeNil())

			userlib.DebugMsg("Bob loading file %s.", bobFile)
			data, err := bob.LoadFile(bobFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentTwo)))

			userlib.DebugMsg("Alice loading file %s.", aliceFile)
			data, err = alice.LoadFile(aliceFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentTwo)))
		})

		Specify("SHARING FILES STORE FILE TEST (Alice overwrites)", func() {
			userlib.DebugMsg("OVERWRITING SHARED FILES, MUILTPLE USER VERSIONS TEST (Alice overwrites)")
			userlib.DebugMsg("Initializing users Alice (aliceDesktop) and Bob.")
			aliceDesktop, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Getting second instance of Alice - aliceLaptop")
			aliceLaptop, err = client.GetUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("aliceDesktop storing file %s with content: %s", aliceFile, contentOne)
			err = aliceDesktop.StoreFile(aliceFile, []byte(contentOne))
			Expect(err).To(BeNil())

			userlib.DebugMsg("aliceLaptop creating invite for Bob.")
			invite, err := aliceLaptop.CreateInvitation(aliceFile, "bob")
			Expect(err).To(BeNil())

			userlib.DebugMsg("Bob accepting invite from Alice under filename %s.", bobFile)
			err = bob.AcceptInvitation("alice", invite, bobFile)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Alice overwriting file %s.", aliceFile)
			err = alice.StoreFile(aliceFile, []byte(contentTwo))
			Expect(err).To(BeNil())

			userlib.DebugMsg("Alice loading file %s.", aliceFile)
			data, err := alice.LoadFile(aliceFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentTwo)))

			userlib.DebugMsg("Bob loading file %s.", bobFile)
			data, err = bob.LoadFile(bobFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentTwo)))
		})

		Specify("TESTING SHARE-CEPTION APPENDING", func() {
			userlib.DebugMsg("TESTING SHARE-CEPTION APPENDING")
			userlib.DebugMsg("Initializing users Alice, Bob, and Charlie.")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())

			charles, err = client.InitUser("charles", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Alice storing file %s with content: %s", aliceFile, contentOne)
			alice.StoreFile(aliceFile, []byte(contentOne))

			userlib.DebugMsg("Alice creating invite for Bob for file %s, and Bob accepting invite under name %s.", aliceFile, bobFile)

			invite, err := alice.CreateInvitation(aliceFile, "bob")
			Expect(err).To(BeNil())

			err = bob.AcceptInvitation("alice", invite, bobFile)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Bob creating invite for Charles for file %s, and Charlie accepting invite under name %s.", bobFile, charlesFile)
			invite, err = bob.CreateInvitation(bobFile, "charles")
			Expect(err).To(BeNil())

			err = charles.AcceptInvitation("bob", invite, charlesFile)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Checking that Charles append to the file.")
			err = charles.AppendToFile(charlesFile, []byte(contentTwo))
			Expect(err).To(BeNil())
			data, err := alice.LoadFile(aliceFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne + contentTwo)))
			data, err = charles.LoadFile(charlesFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne + contentTwo)))
		})

		// THE FOLLOWING TESTS
		// APPENDS A FILE ONTO AN EXISTING FILE, CHANGES THE RGK OF A FILE, THEN CHANGES THE RGK TO THE WRONG LENGTH
		//OUR CODE CATCHES THE ERRORS (TESTS PASS), BUT THE TESTS DON'T TRANSLATE TO OTHER IMPLEMENTATIONS OF THE PROJ SO I'M COMMENTING IT OUT FOR NOW IT
		/*Specify("LoadFile: The integrity of the downloaded content cannot be verified (indicating there have been unauthorized modifications to the file).", func() {
			userlib.DebugMsg("Checking if adversary appended to file")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			err := alice.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())
			hashedusername := userlib.Hash([]byte("alice"))
			hashedfilename := userlib.Hash([]byte("hi"))
			hashedcombine := append(hashedusername, hashedfilename...)
			contentuuid, err := uuid.FromBytes(userlib.Hash(hashedcombine)[:16])
			hashuuid1 := userlib.Hash(contentuuid[:])
			hashappend := userlib.Hash([]byte("append"))
			hashuuid1 = append(hashuuid1, hashappend...)
			nextuuid, err := uuid.FromBytes(userlib.Hash(hashuuid1)[:16])
			userlib.DatastoreSef(nextuuid, []byte("hi"))
			_, err = alice.LoadFile("hi")
			Expect(err).ToNot(BeNil())
		})

		Specify("LoadFile: Loading the file cannot succeed due to any other malicious action.", func() {
			userlib.DebugMsg("Checking if adversary changed the key")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			err := alice.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())
			hashedusername := userlib.Hash([]byte("alice"))
			hashedfilename := userlib.Hash([]byte("hi"))
			hashedcombine := append(hashedusername, hashedfilename...)
			contentuuid, err := uuid.FromBytes(userlib.Hash(hashedcombine)[:16])
			keyuuid, err := uuid.FromBytes(userlib.Hash(contentuuid[:])[0:16])
			userlib.DatastoreSet(keyuuid, userlib.RandomBytes(16))
			_, err = alice.LoadFile("hi")
			Expect(err).ToNot(BeNil())
		})

		Specify("LoadFile: Loading the file cannot succeed due to any other malicious action.", func() {
			userlib.DebugMsg("Checking if adversary made the key nonfunctional")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			err := alice.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())
			hashedusername := userlib.Hash([]byte("alice"))
			hashedfilename := userlib.Hash([]byte("hi"))
			hashedcombine := append(hashedusername, hashedfilename...)
			contentuuid, err := uuid.FromBytes(userlib.Hash(hashedcombine)[:16])
			keyuuid, err := uuid.FromBytes(userlib.Hash(contentuuid[:])[0:16])
			userlib.DatastoreSet(keyuuid, []byte("ojdhebohvfvuohrvcjowhfbcfwjhcvrfiuycvbrfkcjrfbcirvcirucricrtcirvciurjfcfeuocbfelefbcofu"))
			_, err = alice.LoadFile("hi")
			Expect(err).ToNot(BeNil())
		}) */

		Specify("LoadFile: Loading the file cannot succeed due to any other malicious action.", func() {
			userlib.DebugMsg("Loadfile: Adversary only changed the appended portions.")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			err := alice.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())
			ogdatastoremap := make(map[userlib.UUID][]byte)
			for k, v := range userlib.DatastoreGetMap() {
				ogdatastoremap[k] = v
			}
			err = alice.AppendToFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())
			for key := range userlib.DatastoreGetMap() {
				userlib.DatastoreGetMap()[key] = []byte(contentThree)
			}
			for key, value := range ogdatastoremap {
				userlib.DatastoreGetMap()[key] = value
			}
			_, err = alice.LoadFile("hi")
			Expect(err).ToNot(BeNil())
		})

		Specify("AppendtoFile: The given filename does not exist in the personal file namespace of the caller.", func() {
			userlib.DebugMsg("Appendtofile: The given filename does not exist in the personal file namespace of the caller.")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			err := alice.AppendToFile("hi", []byte(contentOne))
			Expect(err).ToNot(BeNil())
		})

		Specify("AppendtoFile: Bandwidth check.", func() {
			measureBandwidth := func(probe func()) (bandwidth int) {
				before := userlib.DatastoreGetBandwidth()
				probe()
				after := userlib.DatastoreGetBandwidth()
				return after - before
			}
			userlib.DebugMsg("AppendtoFile: Bandwidth check.")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			err := alice.StoreFile("hi", []byte(contentOne))
			bwappend1 := measureBandwidth(func() { alice.AppendToFile("hi", []byte(contentOne)) })
			bwload1 := measureBandwidth(func() { alice.LoadFile("hi") })
			k := 0
			for k <= 20 {
				alice.AppendToFile("hi", []byte(contentOne))
				k++
			}
			bwappend2 := measureBandwidth(func() { alice.AppendToFile("hi", []byte(contentOne)) })
			bwload2 := measureBandwidth(func() { alice.LoadFile("hi") })
			Expect(err).To(BeNil())
			Expect(bwappend1).To(Equal(bwappend2))
			Expect(bwload1).To(BeNumerically("<", bwload2))
		})

		Specify("CreateInvitation: addt tests", func() {
			userlib.DebugMsg("CreatInvitation: The given filename does not exist in the personal file namespace of the caller.")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())
			_, err := alice.CreateInvitation("hi", "bob")
			Expect(err).ToNot(BeNil())
		})

		Specify("CreateInvitation: addt tests", func() {
			userlib.DebugMsg("CreatInvitation: The given recipientUsername does not exist.")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			err = alice.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())
			_, err := alice.CreateInvitation("hi", "bob")
			Expect(err).ToNot(BeNil())
		})

		// COMMENTED THESE NEXT TWO OUT B/C THEY DIDN'T GIVE US ANY FLAGS AND MIGHT ACTUALLY BE INCORRECT IN WHAT THEY THINK SHOULD ERROR
		/*Specify("CreateInvitation: addt tests", func() {
			userlib.DebugMsg("CreatInvitation: error when sending a file that's been messed with")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())

			ogdatastoremap := make(map[userlib.UUID][]byte)
			for k, v := range userlib.DatastoreGetMap() {
				ogdatastoremap[k] = v
			}

			err = alice.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())

			for key := range userlib.DatastoreGetMap() {
				userlib.DatastoreGetMap()[key] = []byte(contentThree)
			}
			for key, value := range ogdatastoremap {
				userlib.DatastoreGetMap()[key] = value
			}

			_, err := alice.CreateInvitation("hi", "bob")
			Expect(err).ToNot(BeNil())
		})

		Specify("AcceptInvitation: addt tests", func() {
			userlib.DebugMsg("AcceptInvitation: error when accepting a file that's been messed with")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())
			err = alice.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())
			inviteuuid, err := alice.CreateInvitation("hi", "bob")
			Expect(err).To(BeNil())

			ogdatastoremap := make(map[userlib.UUID][]byte)
			for k, v := range userlib.DatastoreGetMap() {
				ogdatastoremap[k] = v
			}

			alice.StoreFile("hi", []byte(contentThree))

			for key, value := range ogdatastoremap {
				userlib.DatastoreGetMap()[key] = value
			}

			err = bob.AcceptInvitation("alice", inviteuuid, "hi")
			Expect(err).ToNot(BeNil())
		}) */

		Specify("Accept/Revoke Invitation: addl test", func() {
			userlib.DebugMsg("AcceptInvitation: The invitation is no longer valid due to revocation.")
			//alice share a file, immediately revokes it, then bob tries to accept it. Errors
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			err = alice.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())

			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())

			inviteuuid, err := alice.CreateInvitation("hi", "bob")
			Expect(err).To(BeNil())

			err = alice.RevokeAccess("hi", "bob")
			Expect(err).To(BeNil())

			err = bob.AcceptInvitation("alice", inviteuuid, "hi")
			Expect(err).ToNot(BeNil())
		})

		Specify("AcceptInvitation: addt tests", func() {
			userlib.DebugMsg("AcceptInvitation: The caller already has a file with the given filename in their personal file namespace.")
			//so alice has a file called hi and tries to share it with bob, but he already has a file called hi
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			err = alice.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())

			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())
			err = bob.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())

			inviteuuid, err := alice.CreateInvitation("hi", "bob")
			Expect(err).To(BeNil())
			err = alice.RevokeAccess("hi", "bob")
			Expect(err).To(BeNil())
			err = bob.AcceptInvitation("alice", inviteuuid, "hi")
			Expect(err).ToNot(BeNil())
		})

		Specify("AcceptInvitation: addt tests", func() {
			userlib.DebugMsg("AcceptInvitation: what if charles tries to accept an invite that was for bob?--> should error")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			err = alice.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())

			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())

			charles, err = client.InitUser("charles", defaultPassword)
			Expect(err).To(BeNil())

			inviteuuid, err := alice.CreateInvitation("hi", "bob")
			Expect(err).To(BeNil())

			err = charles.AcceptInvitation("alice", inviteuuid, "hi")
			Expect(err).ToNot(BeNil())
		})

		Specify("RevokeAcces: addl tests", func() {
			userlib.DebugMsg("RevokeAccess: The given filename does not exist in the caller’s personal file namespace.")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			alice.StoreFile("hi", []byte(contentOne))

			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())

			inviteuuid, err := alice.CreateInvitation("hi", "bob")
			Expect(err).To(BeNil())
			err = bob.AcceptInvitation("alice", inviteuuid, "hi")
			Expect(err).To(BeNil())

			err = alice.RevokeAccess("bye", "bob")
			Expect(err).ToNot(BeNil())
		})

		Specify("RevokeAcces: addl tests", func() {
			userlib.DebugMsg("RevokeAccess: The given filename is not currently shared with recipientUsername.")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			alice.StoreFile("hi", []byte(contentOne))

			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())

			err = alice.RevokeAccess("hi", "bob")
			Expect(err).ToNot(BeNil())
		})

		Specify("RevokeAccess: addl tests", func() {
			userlib.DebugMsg("RevokeAccess: The given filename is not currently shared with recipientUsername. This time bob doesn't even exist")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			alice.StoreFile("hi", []byte(contentOne))

			err = alice.RevokeAccess("hi", "bob")
			Expect(err).ToNot(BeNil())
		})

		/* Specify("RevokeAcces/Loadfile: addl tests", func() {
			userlib.DebugMsg("RevokeAccess/Loadfile: error if revoked user tries to load the file")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			err = alice.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())
			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())
			inviteuuid, err := alice.CreateInvitation("hi", "bob")
			Expect(err).To(BeNil())
			err = bob.AcceptInvitation("alice", inviteuuid, "hi")
			Expect(err).To(BeNil())
			err = alice.RevokeAccess("hi", "bob")
			Expect(err).To(BeNil())
			_, err = bob.LoadFile("hi")
			Expect(err).ToNot(BeNil())
		})

		Specify("RevokeAcces/Loadfile: addl tests", func() {
			userlib.DebugMsg("RevokeAccess/Loadfile: error if revoked user tries to share the file")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			err = alice.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())
			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())
			inviteuuid, err := alice.CreateInvitation("hi", "bob")
			Expect(err).To(BeNil())
			err = bob.AcceptInvitation("alice", inviteuuid, "hi")
			Expect(err).To(BeNil())
			err = alice.RevokeAccess("hi", "bob")
			Expect(err).To(BeNil())
			charles, err = client.InitUser("charles", defaultPassword)
			Expect(err).To(BeNil())
			_, err = bob.CreateInvitation("hi", "charles")
			Expect(err).ToNot(BeNil())
		})

		Specify("RevokeAcces/Loadfile: addl tests", func() {
			userlib.DebugMsg("RevokeAccess/Loadfile: error if revoked user's descendant tries to accept the invite")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			err = alice.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())
			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())
			inviteuuid, err := alice.CreateInvitation("hi", "bob")
			Expect(err).To(BeNil())
			err = bob.AcceptInvitation("alice", inviteuuid, "hi")
			Expect(err).To(BeNil())
			charles, err = client.InitUser("charles", defaultPassword)
			Expect(err).To(BeNil())
			inviteuuid, err = bob.CreateInvitation("hi", "charles")
			Expect(err).To(BeNil())
			err = alice.RevokeAccess("hi", "bob")
			Expect(err).To(BeNil())
			err = charles.AcceptInvitation("bob", inviteuuid, "hi")
			Expect(err).ToNot(BeNil())
		})

		Specify("RevokeAcces/Loadfile: addl tests", func() {
			userlib.DebugMsg("RevokeAccess/Loadfile: error if revoked user's descendant tries to load the file")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())
			err = alice.StoreFile("hi", []byte(contentOne))
			Expect(err).To(BeNil())
			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())
			inviteuuid, err := alice.CreateInvitation("hi", "bob")
			Expect(err).To(BeNil())
			err = bob.AcceptInvitation("alice", inviteuuid, "hi")
			Expect(err).To(BeNil())
			charles, err = client.InitUser("charles", defaultPassword)
			Expect(err).To(BeNil())
			inviteuuid, err = bob.CreateInvitation("hi", "charles")
			Expect(err).To(BeNil())
			err = charles.AcceptInvitation("bob", inviteuuid, "hi")
			Expect(err).To(BeNil())
			err = alice.RevokeAccess("hi", "bob")
			Expect(err).To(BeNil())
			_, err = charles.LoadFile("hi")
			Expect(err).ToNot(BeNil())
		}) */

		Specify("Testing Revoke Functionality: we can still append afterward?", func() {
			userlib.DebugMsg("Initializing users Alice, Bob, and Charlie.")
			alice, err = client.InitUser("alice", defaultPassword)
			Expect(err).To(BeNil())

			bob, err = client.InitUser("bob", defaultPassword)
			Expect(err).To(BeNil())

			charles, err = client.InitUser("charles", defaultPassword)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Alice storing file %s with content: %s", aliceFile, contentOne)
			alice.StoreFile(aliceFile, []byte(contentOne))

			userlib.DebugMsg("Alice creating invite for Bob for file %s, and Bob accepting invite under name %s.", aliceFile, bobFile)

			invite, err := alice.CreateInvitation(aliceFile, "bob")
			Expect(err).To(BeNil())

			err = bob.AcceptInvitation("alice", invite, bobFile)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Checking that Alice can still load the file.")
			data, err := alice.LoadFile(aliceFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne)))

			userlib.DebugMsg("Checking that Bob can load the file.")
			data, err = bob.LoadFile(bobFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne)))

			userlib.DebugMsg("Bob creating invite for Charles for file %s, and Charlie accepting invite under name %s.", bobFile, charlesFile)
			invite, err = bob.CreateInvitation(bobFile, "charles")
			Expect(err).To(BeNil())

			err = charles.AcceptInvitation("bob", invite, charlesFile)
			Expect(err).To(BeNil())

			userlib.DebugMsg("Checking that Charles can load the file.")
			data, err = charles.LoadFile(charlesFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne)))

			userlib.DebugMsg("Alice revoking Bob's access from %s.", aliceFile)
			err = alice.RevokeAccess(aliceFile, "bob")
			Expect(err).To(BeNil())

			userlib.DebugMsg("Checking that Alice can still load the file.")
			data, err = alice.LoadFile(aliceFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne)))

			userlib.DebugMsg("Checking that Bob/Charles lost access to the file.")
			_, err = bob.LoadFile(bobFile)
			Expect(err).ToNot(BeNil())

			_, err = charles.LoadFile(charlesFile)
			Expect(err).ToNot(BeNil())

			userlib.DebugMsg("Checking that the revoked users cannot append to the file.")
			err = bob.AppendToFile(bobFile, []byte(contentTwo))
			Expect(err).ToNot(BeNil())

			err = charles.AppendToFile(charlesFile, []byte(contentTwo))
			Expect(err).ToNot(BeNil())

			userlib.DebugMsg("Checking that Alice can still append to the file.")
			err = alice.AppendToFile(aliceFile, []byte(contentTwo))
			Expect(err).To(BeNil())
			data, err = alice.LoadFile(aliceFile)
			Expect(err).To(BeNil())
			Expect(data).To(Equal([]byte(contentOne + contentTwo)))
		})
	})
})
